package br.uniube.projeto;

import java.util.Scanner;

public class Jogo {
	Scanner entrada = new Scanner(System.in);
	int y =0;
	public void Saudacao() {
		System.out.println("\n");
		System.out.println("\nSeja bem vindo ao jogo de perguntas e respostas sobre o Covid-19");
		System.out.println("\nEsse jogo tem como objetivo testar seus conhecimentos sobre esse virus");
		System.out.println("\nVoce sera pontuado em uma escala de 0 a 10");
		System.out.println("\nQuanto melhor voce for, mais voce prova que e um guerreiro exemplar contra esse virus");
		System.out.println("\n");
		System.out.println("Se divirta!!! Obrigado por jogar!!!");
		System.out.println("\n");
	}
	public void Arte() {
		System.out.println("\n");
		System.out.println("         _____          ___              _________             ___       ");
		System.out.println("         XXXXX          XXX          ____XXXXXXXXX             XXX       ");
		System.out.println("         XXXXX        XXX XXX        XXXXXXXXXXXXXXX         XXX XXX     ");
		System.out.println("         XXXXX       XXX   XXX       XXXXX                  XXX   XXX    ");
		System.out.println("         XXXXX      XXX     XXX      XXXXX                 XXX     XXX   ");
		System.out.println("         XXXXX     XXX       XXX     XXXXX                XXX       XXX  ");
		System.out.println(" ____    XXXXX    XXX         XXX    XXXXX    _______    XXX         XXX ");
		System.out.println(" XXXX    XXXXX    XXX         XXX    XXXXX    XXXXXXX_   XXX         XXX ");
		System.out.println(" XXXX    XXXXX     XXX       XXX     XXXXX       XXXXX    XXX       XXX  ");
		System.out.println("  XXXX  XXXXX       XXX     XXX      XXXXX_______XXXXX     XXX     XXX   ");
		System.out.println("    XXXXXXXX         XXX___XXX         XXXXXXXXXXX          XXX___XXX    ");
		System.out.println("     XXXXXX            XXXXX            XXXXXXXXX             XXXXX      ");
		System.out.println("\n");
	}
	public void Questao1() {
		System.out.println("\n");
		System.out.println("Questao 1) Quais desses sintomas nao sao causados pelo Coronavirus?");
		System.out.println("\n");
		System.out.println("(a) Tosse");
		System.out.println("(b) Dor de cabeca");
		System.out.println("(c) Coriza");
		System.out.println("(d) Dor de garganta");
		System.out.println("(e) Febre");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("d")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: d");
		}
	}
	public void Questao2() {
		System.out.println("\n");
		System.out.println("Questao 2) Quais das opcoes esta mais correta?");
		System.out.println("\n");
		System.out.println("(a) Nunca use mascara");
		System.out.println("(b) Use mascara somente quando for sair");
		System.out.println("(c) Use mascara quando estiver proximo de outras pessoas");
		System.out.println("(d) Use mascara somente em casa");
		System.out.println("(e) Use mascara quando estiver proximo de pessoas e quando estiver em casa");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("e")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: e");
		}
	}
	public void Questao3() {
		System.out.println("\n");
		System.out.println("Questao 3) Qual desse virus nao e da classe Corona?");
		System.out.println("\n");
		System.out.println("(a) Alpha coronav�rus 229E ");
		System.out.println("(b) Beta coronav�rus OC53 ");
		System.out.println("(c) SARS-CoV");
		System.out.println("(d) MERS-CoV");
		System.out.println("(e) nCoV-2019");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("b")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: b");
		}
	}
	public void Questao4() {
		System.out.println("\n");
		System.out.println("Questao 4) Qual e a distancia minima recomendada que voce deve ter com as pessoas");
		System.out.println("\n");
		System.out.println("(a) No minimo 2m");
		System.out.println("(b) No minimo 1m");
		System.out.println("(c) No minimo 10m");
		System.out.println("(d) No minimo 1cm");
		System.out.println("(e) Nao tem distancia minima");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("a")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: a");
		}
	}
	public void Questao5() {
		System.out.println("\n");
		System.out.println("Questao 5) Qual foi a data da descoberta desse novo Coronavirus?");
		System.out.println("\n");
		System.out.println("(a) 18/11/19");
		System.out.println("(b) 25/12/19");
		System.out.println("(c) 11/09/19");
		System.out.println("(d) 10/10/19");
		System.out.println("(e) 31/12/19");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("e")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: e");
		}
	}
	public void Questao6() {
		System.out.println("\n");
		System.out.println("Questao 6) Qual e a melhor porcentagem de alcool nos Alcool Gel Antissepticos para o combate ao Covid-19?");
		System.out.println("\n");
		System.out.println("(a) 100%");
		System.out.println("(b) 40%");
		System.out.println("(c) 70%");
		System.out.println("(d) 80%");
		System.out.println("(e) 50%");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("c")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: c");
		}
	}
	public void Questao7() {
		System.out.println("\n");
		System.out.println("Questao 7) O que voce deve fazer se comecar a sentir sintomas de gripe?");
		System.out.println("\n");
		System.out.println("(a) Sair correndo para o hospital");
		System.out.println("(b) Nao dar a minima");
		System.out.println("(c) Ficar em casa por 14 dias e ir ao hospital se sentir falta de ar");
		System.out.println("(d) Nao saia de casa ");
		System.out.println("(e) Ir ao hospital quando sentir falta de ar");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("c")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: c");
		}
	}
	public void Questao8() {
		System.out.println("\n");
		System.out.println("Questao 8) Somente em quais circustancias voce pode sair de casa?");
		System.out.println("\n");
		System.out.println("(a) Para comprar alimentos ou medicamentos");
		System.out.println("(b) Para trabalhar e realizar suas atividades diarias");
		System.out.println("(c) Nao saia de caa sob hipotese nenhuma");
		System.out.println("(d) So saia para fazer exercicios fisicos");
		System.out.println("(e) So va para a casa de parentes");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("a")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: a");
		}
	}
	public void Questao9() {
		System.out.println("\n");
		System.out.println("Questao 9) Se voce der positivo para Covid-19 o que deve fazer?");
		System.out.println("\n");
		System.out.println("(a) Se isole de todos");
		System.out.println("(b) So nao saia de casa");
		System.out.println("(c) Fique tranquilo");
		System.out.println("(d) Use mascara o tempo todo, separe seus itens pessoais");
		System.out.println("(e) Conte com a ajuda de seus familiares");
		System.out.println("\n");
		String x = entrada.next();
		if(x.equals("d")) {
			System.out.println("Voce acertou!!!");
			y++;
		}
		else {
			System.out.println("Voce errou!!!");
			System.out.println("A resposta certa e: d");
		}
	}
	public void Questao10() {
	System.out.println("\n");
	System.out.println("Questao 10) Quais estado brasileiro tem mais casos confirmados de Covid-19?");
	System.out.println("OBS: Referente a data de 23/05/20");
	System.out.println("\n");
	System.out.println("(a) Nordeste");
	System.out.println("(b) Sudeste");
	System.out.println("(c) Centro-Oeste");
	System.out.println("(d) Norte");
	System.out.println("(e) Sul");
	System.out.println("\n");
	String x = entrada.next();
	if(x.equals("b")) {
		System.out.println("Voce acertou!!!");
		y++;
	}
	else {
		System.out.println("Voce errou!!!");
		System.out.println("A resposta certa e: b");
		 }
	}
	public void Resultado() {
		System.out.println("\n");
		System.out.printf("Sua pontuacao foi de: %d pontos\n", y);
		if(y<=4 && y>=0) {
			System.out.println("Voce precisa se atualizar sobre o assunto");
		}
		else if(y<=7 && y>=5) {
			System.out.println("Seu conhecimento ainda nao e o suficiente");
		}
		else if(y<=10 && y>=8) {
			System.out.println("Parabens seus conhecimentos sobre o assunto estao otimos");
		}
		System.out.println("Deseja jogar novamente?");
		System.out.println("\n");
	}
}
