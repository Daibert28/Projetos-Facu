package br.uniube.projeto;

import java.util.Scanner;

public class Textos {
	public void Oq() {
		System.out.println("\n");
		System.out.println("------------------------");
		System.out.println("O QUE E O CORONA VIRUS :");
		System.out.println("------------------------");
		System.out.println("\n");
		System.out.println("\nCoronav�rus � uma fam�lia de v�rus que causam infec��es respirat�rias. ");
		System.out.println("O novo agente do coronav�rus foi descoberto em 31/12/19 ap�s casos registrados na China. ");
		System.out.println("Provoca a doen�a chamada de coronav�rus (COVID-19).");
		System.out.println("\n");
	}
	public void Sintomas() {
		System.out.println("\n");
		System.out.println("---------");
		System.out.println("SINTOMAS :");
		System.out.println("---------");
		System.out.println("\n");
		System.out.println("\nOs sintomas da COVID-19 podem variar de um simples resfriado at� uma pneumonia severa. Sendo os sintomas mais comuns:");
		System.out.println("\nTosse;");
		System.out.println("\nFebre;");
		System.out.println("\nCoriza;");
		System.out.println("\nDor de cabeca;");
		System.out.println("\nDificuldade de respirar;");
		System.out.println("\n");
	}
	public void Transmissao() {
		System.out.println("----------------------");
		System.out.println("MEIOS DE TRANSMISSAO :");
		System.out.println("----------------------");
		System.out.println("\n");
		System.out.println("\nA transmiss�o acontece de uma pessoa doente para outra ou por contato pr�ximo por meio de: ");
		System.out.println("\nToque de aperto de mao;");
		System.out.println("\nGoticulas de saliva;");
		System.out.println("\nEspirro;");
		System.out.println("\nTosse;");
		System.out.println("\nCatarro;");
		System.out.println("\nObjetos ou superf�cies contaminadas, como celulares, mesas, ma�anetas, brinquedos, teclados de computador etc.");
		System.out.println("\n");
	}
	public void Protecao() {
		System.out.println("------------------");
		System.out.println("COMO SE PROTEGER :");
		System.out.println("------------------");
		System.out.println("\n");
		System.out.println("\nLave com frequ�ncia as m�os at� a altura dos punhos, com �gua e sab�o, ou ent�o higienize com �lcool em gel 70%.");
		System.out.println("\nAo tossir ou espirrar, cubra nariz e boca com len�o ou com o bra�o, e n�o com as m�os.");
		System.out.println("\nEvite tocar olhos, nariz e boca com as m�os n�o lavadas.");
		System.out.println("\nAo tocar, lave sempre as m�os como j� indicado.");
		System.out.println("\nMantenha uma dist�ncia m�nima de cerca de 2 metros de qualquer pessoa tossindo ou espirrando.");
		System.out.println("\nEvite abra�os, beijos e apertos de m�os. Adote um comportamento amig�vel sem contato f�sico, mas sempre com um sorriso no rosto.");
		System.out.println("\nHigienize com frequ�ncia o celular e os brinquedos das crian�as.");
		System.out.println("\nN�o compartilhe objetos de uso pessoal, como talheres, toalhas, pratos e copos.");
		System.out.println("\nMantenha os ambientes limpos e bem ventilados.");
		System.out.println("\nEvite circula��o desnecess�ria nas ruas, est�dios, teatros, shoppings, shows, cinemas e igrejas. Se puder, fique em casa.");
		System.out.println("\nSe estiver doente, evite contato f�sico com outras pessoas, principalmente idosos e doentes cr�nicos, e fique em casa at� melhorar.");
		System.out.println("\nDurma bem e tenha uma alimenta��o saud�vel.");
		System.out.println("\nUtilize m�scaras caseiras ou artesanais feitas de tecido em situa��es de sa�da de sua resid�ncia. ");
		System.out.println("\n");
	}
	public void Tratamento() {
		System.out.println("------------");
		System.out.println("TRATAMENTO :");
		System.out.println("------------");
		System.out.println("\n");
		System.out.println("Caso voc� se sinta doente, com sintomas de gripe, evite contato f�sico com outras pessoas, principalmente idosos e doentes cr�nicos");
		System.out.println("e fique em casa por 14 dias.");
		System.out.println("\nS� procure um hospital de refer�ncia se estiver com falta de ar.");
		System.out.println("\n CASO O SEU RESULTADO SEJA POSITIVO");
		System.out.println("\nFique em isolamento domiciliar.");
		System.out.println("\nUtilize m�scara o tempo todo.");
		System.out.println("\nSe for preciso cozinhar, use m�scara de prote��o, cobrindo boca e nariz todo o tempo.");
		System.out.println("\nSepare toalhas de banho, garfos, facas, colheres, copos e outros objetos apenas para seu uso.");
		System.out.println("\nO lixo produzido precisa ser separado e descartado.");
		System.out.println("\nSof�s e cadeiras tamb�m n�o podem ser compartilhados e precisam ser limpos frequentemente com �gua sanit�ria ou �lcool 70%.");
		System.out.println("\n");
		System.out.println("\nCaso o paciente n�o more sozinho, os demais moradores da devem dormir em outro c�modo, longe da pessoa infectada, seguindo tamb�m");
		System.out.println("as seguintes recomenda��es:");
		System.out.println("\n");
		System.out.println("\nManter a dist�ncia m�nima de 1 metro entre o paciente e os demais moradores.");
		System.out.println("\nLimpe os m�veis da casa frequentemente com �gua sanit�ria ou �lcool 70%.");
		System.out.println("\nSe uma pessoa da casa tiver diagn�stico positivo, todos os moradores ficam em isolamento por 14 dias tamb�m.");
		System.out.println("\nCaso outro familiar da casa tamb�m inicie os sintomas leves, ele deve reiniciar o isolamento de 14 dias. Se os sintomas forem graves,");
		System.out.println("como dificuldade para respirar, ele deve procurar orienta��o m�dica.");
		System.out.println("\n");
	}
	public void Tipos() {
		System.out.println("--------------------");
		System.out.println("TIPOS DE CORONAVIRUS");
		System.out.println("--------------------");
		System.out.println("\n");
		System.out.println("\nAlpha coronav�rus 229E e NL63;");
		System.out.println("\nBeta coronav�rus OC43 e HKU1;");
		System.out.println("\nSARS-CoV (causador da S�ndrome Respirat�ria Aguda Grave ou SARS);");
		System.out.println("\nMERS-CoV (causador da S�ndrome Respirat�ria do Oriente M�dio ou MERS);");
		System.out.println("\nnCoV-2019: novo tipo de v�rus do agente coronav�rus, chamado de novo coronav�rus, que surgiu na China em 31 de dezembro de 2019.");
		System.out.println("\n");
	}
	public void Creditos() {
		System.out.println("\n");
		System.out.println("Estudante criador do programa: Pedro Daibert e Kauane Silva");
		System.out.println("\n");
		System.out.println("Objetivo do programa: Usado como projeto final do 3� periodo e para testar os conhecimentos dos usuarios participantes");
		System.out.println("\n");
		System.out.println("TODAS AS INFORMACOES CONTIDAS NESSE PROGRAMA SOBRE O COVID-19 FORAM TIRADAS DIRETAMENTE DO SITE DO MINISTERIO DA SAUDE");
		System.out.println("\n");
		System.out.println("Nos Pedro Daibert e Kauane Silva agradecemos por jogarem nosso jogo!");
	}
}
