﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_com_BancodeDados
{
    public partial class Form1 : Form
    {
        List<string> Agenda = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost; port=3306; Database=agenda_2;Uid=root;Password=Spartan118.";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();

                if (txtnome.Text.Equals(null) || txtnome.Text.Equals(""))
                {
                    MessageBox.Show("Forneça algum nome por favor!");
                }
                else if (txtra.Text.Equals(null) || txtra.Text.Equals(""))
                {
                    MessageBox.Show("Forneça algum nome por favor!");
                }
                else if (txtdata.Text.Equals(null) || txtdata.Text.Equals(""))
                {
                    MessageBox.Show("Forneça algum nome por favor!");
                }
                else if (txtcompromisso.Text.Equals(null) || txtcompromisso.Text.Equals(""))
                {
                    MessageBox.Show("Forneça algum nome por favor!");
                }
                else
                {
                    command.CommandText = "INSERT INTO tabela_2 (txtnome, txtra, txtdata, txtcompromisso) VALUES ('" + txtnome.Text + "','" + txtra.Text + "','" + txtdata.Text + "','" + txtcompromisso + "')";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos!!!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possivel estabelecer conexão!! :( \n" + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost; port=3306; Database=agenda_2;Uid=root;Password=Spartan118.";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();
                if (!txtnome.Text.Equals(null) && !txtnome.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM tabela_2 WHERE txtnome = '" + txtnome.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Dado apagado com sucesso!!! :)");
                }
                else if (!txtra.Text.Equals(null) && !txtra.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM tabela_2 WHERE txtra = '" + txtra.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Dado apagado com sucesso!!! :)");
                }
                else if (!txtdata.Text.Equals(null) && !txtdata.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM tabela_2 WHERE txtdata = '" + txtdata.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Dado apagado com sucesso!!! :)");
                }
                else if (!txtcompromisso.Text.Equals(null) && !txtcompromisso.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM tabela_2 WHERE txtcompromisso = '" + txtcompromisso.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Dado apagado com sucesso!!! :)");
                }
                else
                {
                    MessageBox.Show("Insira algum dado para ser deletado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possivel estabelecer conexão!! :( \n" + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void bbusca_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost; port=3306; Database=agenda_2;Uid=root;Password=Spartan118.";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();
                command.CommandText = "SELECT txtnome, txtra, txtdata, txtcompromisso FROM tabela_2";
                var it = command.ExecuteReader();
                String nome, ra, data_compromisso, compromisso, resultado = "NOME | RA | DATA_COMPROMISSO | COMPROMISSO\n";
                while (it.Read())
                {
                    nome = it.GetString("txtnome");
                    resultado += nome + " | ";
                    ra = it.GetString("txtra");
                    resultado += ra + " \n ";
                    data_compromisso = it.GetString("txtdata");
                    resultado += data_compromisso + " \n ";
                    compromisso = it.GetString("txtcompromisso");
                    resultado += compromisso + " \n ";
                }
                MessageBox.Show(resultado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possivel estabelecer uma conexão! :( \n" + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost; port=3306; Database=agenda_2;Uid=root;Password=Spartan118.";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();
                MessageBox.Show("Conectado!!! :)");
                connection.Close();
            }

            catch
            {
                MessageBox.Show("Não esta Conectado!!! :(");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost; port=3306; Database=agenda_2;Uid=root;Password=Spartan118.";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();
                DateTime dtAgenda = new DateTime();
                command.CommandText = "SELECT txtnome, txtra, txtdata, txtcompromisso FROM tabela_2";
                var it = command.ExecuteReader();
                String nome, ra, data_compromisso, resultado = "NOME | RA | DATA_COMPROMISSO | COMPROMISSO\n";
                while (it.Read())
                {
                    nome = it.GetString("txtnome");
                    resultado += nome + " | ";
                    ra = it.GetString("txtra");
                    resultado += ra + " \n ";
                    data_compromisso = it.GetString("txtdata");
                    resultado += data_compromisso + " \n ";

                }

                if (dtAgenda == DateTime.Now)
                {

                    MessageBox.Show("A data do seu compromisso chegou!", "Lembrete");

                }
                connection.Close();
            }
            catch
            {
                MessageBox.Show("Não esta Conectado!!! :(");
            }
        }

        private void txtra_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcompromisso_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
