package br.uniube.projeto;

import java.util.Scanner;

public class Programa {

	public static void main(String args[]) {
		Scanner entrada = new Scanner(System.in);
		Textos objTextos = new Textos();
		Jogo objJogo = new Jogo();
		
		int opcao;
		do {
		System.out.println("|-------------------------|");
		System.out.println("|       MENU DE OPCOES    |");
		System.out.println("|[1] - Ler as informacoes |");
		System.out.println("|[2] - Jogar              |");
		System.out.println("|[3] - Creditos e Fontes  |");
		System.out.println("|[4] - Sair               |");
		System.out.println("|-------------------------|");
		System.out.println("\n");
		System.out.println("|-------------------------------------------|");
		System.out.println("|E recomendado ler as opcoes antes de jogar |");
		System.out.println("|-------------------------------------------|");
		System.out.println("\n");
		System.out.println("|-------------------------|");
		System.out.println("|DIGITE A OPCAO DESEJADA: |");
		System.out.println("|-------------------------|");
		
		
		opcao = entrada.nextInt();
		if(opcao == 1) { 
			int opcao2;
			do {
			System.out.println("|-------------------------|");
			System.out.println("|       MENU DE OPCOES    |");
			System.out.println("|[1] - O que �            |");
			System.out.println("|[2] - Sintomas           |");
			System.out.println("|[3] - Transmissao        |");
			System.out.println("|[4] - Protecao           |");
			System.out.println("|[5] - Tratamento         |");
			System.out.println("|[6] - Tipos              |");
			System.out.println("|[7] - Sair               |");
			System.out.println("|-------------------------|");
			
			
			opcao2 = entrada.nextInt();
				if(opcao2 == 1) {
				objTextos.Oq();
			}
			else if(opcao2 == 2) {
				objTextos.Sintomas();
			}
			else if(opcao2 == 3) {
				objTextos.Transmissao();
			}
			else if(opcao2 == 4) {
				objTextos.Protecao();
			}
			else if(opcao2 == 5) {
				objTextos.Tratamento();
			}
			else if(opcao2 == 6) {
				objTextos.Tipos();
			}
		  }while(opcao2 != 7);
		}
		else if(opcao == 2) {
			objJogo.Arte();
			objJogo.Saudacao();
			objJogo.Questao1();
			objJogo.Questao2();
			objJogo.Questao3();
			objJogo.Questao4();
			objJogo.Questao5();
			objJogo.Questao6();
			objJogo.Questao7();
			objJogo.Questao8();
			objJogo.Questao9();
			objJogo.Questao10();
			objJogo.Resultado();
		}
		else if(opcao == 3) {
			objTextos.Creditos();
		}
		}while(opcao != 4);
	}
}